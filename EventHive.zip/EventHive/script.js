// SecureShield WAF Dashboard JavaScript
class SecureShieldDashboard {
  constructor() {
    this.currentSection = 'dashboard';
    this.charts = {};
    this.realTimeData = {
      currentRPS: 1247,
      avgResponseTime: 12,
      activeConnections: 5432,
      bandwidthUsage: 847
    };
    
    this.init();
  }

  init() {
    this.setupNavigation();
    this.setupCharts();
    this.setupThreatsTable();
    this.setupRuleBuilder();
    this.setupRealTimeUpdates();
    this.setupFormHandlers();
    this.setupResponsiveDesign();
  }

  // Navigation System
  setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.section');

    navItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const targetSection = item.dataset.section;
        this.navigateToSection(targetSection);
        this.updateNavigation(item);
      });
    });
  }

  navigateToSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
      section.classList.remove('active');
    });

    // Show target section
    const targetSection = document.getElementById(`${sectionId}-section`);
    if (targetSection) {
      targetSection.classList.add('active');
      this.currentSection = sectionId;
      this.updatePageTitle(sectionId);
      this.updateBreadcrumb(sectionId);
    }
  }

  updateNavigation(activeItem) {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.remove('active');
    });
    activeItem.classList.add('active');
  }

  updatePageTitle(sectionId) {
    const titles = {
      dashboard: 'Security Dashboard',
      rules: 'Rules Engine',
      threats: 'Threat Detection',
      traffic: 'Traffic Monitoring',
      policies: 'Security Policies',
      incidents: 'Incident Response'
    };

    const pageTitle = document.querySelector('.page-title');
    const breadcrumbCurrent = document.querySelector('.breadcrumb .current');
    
    if (pageTitle && titles[sectionId]) {
      pageTitle.textContent = titles[sectionId];
      breadcrumbCurrent.textContent = titles[sectionId];
    }
  }

  updateBreadcrumb(sectionId) {
    const breadcrumb = document.querySelector('.breadcrumb');
    const sectionNames = {
      dashboard: 'Dashboard',
      rules: 'Rules Engine',
      threats: 'Threat Detection',
      traffic: 'Traffic Monitoring',
      policies: 'Security Policies',
      incidents: 'Incident Response'
    };

    breadcrumb.innerHTML = `<span>Home</span> / <span class="current">${sectionNames[sectionId] || 'Dashboard'}</span>`;
  }

  // Chart Setup and Management
  setupCharts() {
    this.setupTrafficChart();
    this.setupAttackChart();
    this.setupChartControls();
  }

  setupTrafficChart() {
    const ctx = document.getElementById('trafficChart');
    if (!ctx) return;

    const data = this.generateTrafficData('24h');
    
    this.charts.traffic = new Chart(ctx, {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [{
          label: 'Requests',
          data: data.requests,
          borderColor: '#2563eb',
          backgroundColor: 'rgba(37, 99, 235, 0.1)',
          borderWidth: 2,
          fill: true,
          tension: 0.4
        }, {
          label: 'Blocked',
          data: data.blocked,
          borderColor: '#ef4444',
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          borderWidth: 2,
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            labels: {
              color: '#cbd5e1'
            }
          }
        },
        scales: {
          x: {
            ticks: {
              color: '#94a3b8'
            },
            grid: {
              color: '#334155'
            }
          },
          y: {
            ticks: {
              color: '#94a3b8'
            },
            grid: {
              color: '#334155'
            }
          }
        }
      }
    });
  }

  setupAttackChart() {
    const ctx = document.getElementById('attackChart');
    if (!ctx) return;

    this.charts.attack = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['SQL Injection', 'XSS', 'DDoS', 'Bot Traffic', 'Other'],
        datasets: [{
          data: [35, 25, 20, 15, 5],
          backgroundColor: [
            '#ef4444',
            '#f59e0b',
            '#06b6d4',
            '#8b5cf6',
            '#10b981'
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              color: '#cbd5e1',
              padding: 15
            }
          }
        }
      }
    });
  }

  setupChartControls() {
    const chartControls = document.querySelectorAll('.chart-controls .btn-small');
    
    chartControls.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Update button states
        chartControls.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Update chart data
        const period = button.dataset.period;
        if (period && this.charts.traffic) {
          const newData = this.generateTrafficData(period);
          this.charts.traffic.data.labels = newData.labels;
          this.charts.traffic.data.datasets[0].data = newData.requests;
          this.charts.traffic.data.datasets[1].data = newData.blocked;
          this.charts.traffic.update();
        }
      });
    });
  }

  generateTrafficData(period) {
    const now = new Date();
    const labels = [];
    const requests = [];
    const blocked = [];

    let intervals, labelFormat, dataPoints;

    switch (period) {
      case '24h':
        intervals = 24;
        labelFormat = (date) => date.getHours().toString().padStart(2, '0') + ':00';
        dataPoints = 24;
        break;
      case '7d':
        intervals = 7;
        labelFormat = (date) => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][date.getDay()];
        dataPoints = 7;
        break;
      case '30d':
        intervals = 30;
        labelFormat = (date) => (date.getMonth() + 1) + '/' + date.getDate();
        dataPoints = 30;
        break;
      default:
        intervals = 24;
        labelFormat = (date) => date.getHours().toString().padStart(2, '0') + ':00';
        dataPoints = 24;
    }

    for (let i = dataPoints - 1; i >= 0; i--) {
      const date = new Date(now);
      
      if (period === '24h') {
        date.setHours(date.getHours() - i);
      } else if (period === '7d') {
        date.setDate(date.getDate() - i);
      } else if (period === '30d') {
        date.setDate(date.getDate() - i);
      }

      labels.push(labelFormat(date));
      
      // Generate realistic data with some randomness
      const baseRequests = 100000 + Math.random() * 50000;
      const baseBlocked = baseRequests * (0.01 + Math.random() * 0.02);
      
      requests.push(Math.floor(baseRequests));
      blocked.push(Math.floor(baseBlocked));
    }

    return { labels, requests, blocked };
  }

  // Threats Table Management
  setupThreatsTable() {
    this.renderThreatsTable();
    
    // Auto-refresh threats table every 30 seconds
    setInterval(() => {
      this.renderThreatsTable();
    }, 30000);
  }

  renderThreatsTable() {
    const tableBody = document.getElementById('threatsTableBody');
    if (!tableBody) return;

    const threats = this.generateThreatData();
    
    tableBody.innerHTML = threats.map(threat => `
      <div class="threat-row">
        <div class="threat-cell">${threat.id}</div>
        <div class="threat-cell">${threat.type}</div>
        <div class="threat-cell">
          <span class="severity-badge ${threat.severity.toLowerCase()}">${threat.severity}</span>
        </div>
        <div class="threat-cell">${threat.source}</div>
        <div class="threat-cell">
          <span class="status-badge ${threat.status.toLowerCase()}">${threat.status}</span>
        </div>
        <div class="threat-cell">${threat.time}</div>
      </div>
    `).join('');
  }

  generateThreatData() {
    const threatTypes = ['SQL Injection', 'XSS Attack', 'DDoS', 'Bot Traffic', 'Malware', 'Brute Force'];
    const severities = ['High', 'Medium', 'Low'];
    const statuses = ['Blocked', 'Mitigated'];
    
    const threats = [];
    
    for (let i = 0; i < 10; i++) {
      const now = new Date();
      const timeAgo = new Date(now.getTime() - Math.random() * 24 * 60 * 60 * 1000);
      
      threats.push({
        id: `THR-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
        type: threatTypes[Math.floor(Math.random() * threatTypes.length)],
        severity: severities[Math.floor(Math.random() * severities.length)],
        source: this.generateRandomIP(),
        status: statuses[Math.floor(Math.random() * statuses.length)],
        time: this.formatTimeAgo(timeAgo)
      });
    }
    
    return threats.sort((a, b) => b.time.localeCompare(a.time));
  }

  generateRandomIP() {
    return [1, 2, 3, 4].map(() => Math.floor(Math.random() * 255)).join('.');
  }

  formatTimeAgo(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);

    if (diffMins < 60) {
      return `${diffMins}m ago`;
    } else if (diffHours < 24) {
      return `${diffHours}h ago`;
    } else {
      return `${Math.floor(diffHours / 24)}d ago`;
    }
  }

  // Rule Builder Functionality
  setupRuleBuilder() {
    const testRuleBtn = document.getElementById('testRule');
    const saveRuleBtn = document.getElementById('saveRule');

    if (testRuleBtn) {
      testRuleBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.testRule();
      });
    }

    if (saveRuleBtn) {
      saveRuleBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.saveRule();
      });
    }

    // Auto-populate rule template based on type selection
    const ruleTypeSelect = document.getElementById('ruleType');
    if (ruleTypeSelect) {
      ruleTypeSelect.addEventListener('change', (e) => {
        this.populateRuleTemplate(e.target.value);
      });
    }
  }

  testRule() {
    const ruleName = document.getElementById('ruleName')?.value;
    const ruleType = document.getElementById('ruleType')?.value;
    const ruleCondition = document.getElementById('ruleCondition')?.value;

    if (!ruleName || !ruleCondition) {
      alert('Please fill in all required fields');
      return;
    }

    // Simulate rule testing
    const testBtn = document.getElementById('testRule');
    const originalText = testBtn.textContent;
    
    testBtn.textContent = 'Testing...';
    testBtn.disabled = true;

    setTimeout(() => {
      testBtn.textContent = originalText;
      testBtn.disabled = false;
      
      // Simulate test results
      const success = Math.random() > 0.3;
      
      if (success) {
        this.showNotification('Rule test passed! No syntax errors detected.', 'success');
      } else {
        this.showNotification('Rule test failed. Please check syntax.', 'error');
      }
    }, 2000);
  }

  saveRule() {
    const ruleName = document.getElementById('ruleName')?.value;
    const ruleType = document.getElementById('ruleType')?.value;
    const ruleCondition = document.getElementById('ruleCondition')?.value;

    if (!ruleName || !ruleCondition) {
      alert('Please fill in all required fields');
      return;
    }

    // Simulate rule saving
    const saveBtn = document.getElementById('saveRule');
    const originalText = saveBtn.textContent;
    
    saveBtn.textContent = 'Saving...';
    saveBtn.disabled = true;

    setTimeout(() => {
      saveBtn.textContent = originalText;
      saveBtn.disabled = false;
      
      this.showNotification('Rule saved successfully!', 'success');
      
      // Clear form
      document.getElementById('ruleName').value = '';
      document.getElementById('ruleCondition').value = '';
    }, 1500);
  }

  populateRuleTemplate(ruleType) {
    const ruleCondition = document.getElementById('ruleCondition');
    if (!ruleCondition) return;

    const templates = {
      'SQL Injection': `SecRule REQUEST_BODY "@detectSQLi" \\
  "id:1001,
   phase:2,
   block,
   msg:'SQL Injection Attack',
   logdata:'Matched Data: %{MATCHED_VAR} found within %{MATCHED_VAR_NAME}',
   tag:'application-multi',
   tag:'language-multi',
   tag:'platform-multi',
   tag:'attack-sqli'"`,
      
      'XSS Prevention': `SecRule ARGS "@detectXSS" \\
  "id:1002,
   phase:2,
   block,
   msg:'XSS Attack Detected',
   logdata:'Matched Data: %{MATCHED_VAR} found within %{MATCHED_VAR_NAME}',
   tag:'application-multi',
   tag:'language-multi',
   tag:'platform-multi',
   tag:'attack-xss'"`,
      
      'Rate Limiting': `SecAction \\
  "id:1003,
   phase:1,
   initcol:IP=%{REMOTE_ADDR},
   setvar:IP.requests_per_minute=+1,
   expirevar:IP.requests_per_minute=60,
   msg:'Rate limiting rule'"

SecRule IP:REQUESTS_PER_MINUTE "@gt 100" \\
  "id:1004,
   phase:1,
   deny,
   msg:'Client IP exceeded rate limit'"`,
      
      'Custom': '# Enter your custom ModSecurity rule here'
    };

    ruleCondition.value = templates[ruleType] || templates['Custom'];
  }

  // Real-time Data Updates
  setupRealTimeUpdates() {
    this.updateMetrics();
    this.updateTrafficStats();
    
    // Update every 5 seconds
    setInterval(() => {
      this.updateMetrics();
      this.updateTrafficStats();
    }, 5000);
  }

  updateMetrics() {
    // Simulate real-time metric updates with small variations
    const metrics = document.querySelectorAll('.metric-value');
    
    metrics.forEach((metric, index) => {
      const currentValue = parseInt(metric.textContent.replace(/[^\d]/g, ''));
      let newValue;
      
      switch (index) {
        case 0: // Total Requests
          newValue = currentValue + Math.floor(Math.random() * 1000);
          metric.textContent = newValue.toLocaleString();
          break;
        case 1: // Blocked Threats
          newValue = currentValue + Math.floor(Math.random() * 10);
          metric.textContent = newValue.toLocaleString();
          break;
        case 2: // Response Time
          newValue = Math.max(8, currentValue + (Math.random() - 0.5) * 4);
          metric.textContent = Math.floor(newValue) + 'ms';
          break;
        case 3: // Uptime
          // Keep uptime relatively stable
          const uptimeVariation = (Math.random() - 0.5) * 0.01;
          newValue = Math.min(100, Math.max(99, parseFloat(metric.textContent) + uptimeVariation));
          metric.textContent = newValue.toFixed(2) + '%';
          break;
      }
    });
  }

  updateTrafficStats() {
    // Update real-time traffic statistics
    const rpsElement = document.getElementById('currentRPS');
    const responseTimeElement = document.getElementById('avgResponseTime');
    const connectionsElement = document.getElementById('activeConnections');
    const bandwidthElement = document.getElementById('bandwidthUsage');

    if (rpsElement) {
      this.realTimeData.currentRPS += Math.floor((Math.random() - 0.5) * 200);
      this.realTimeData.currentRPS = Math.max(500, Math.min(3000, this.realTimeData.currentRPS));
      rpsElement.textContent = this.realTimeData.currentRPS.toLocaleString();
    }

    if (responseTimeElement) {
      this.realTimeData.avgResponseTime += Math.floor((Math.random() - 0.5) * 4);
      this.realTimeData.avgResponseTime = Math.max(8, Math.min(50, this.realTimeData.avgResponseTime));
      responseTimeElement.textContent = this.realTimeData.avgResponseTime + 'ms';
    }

    if (connectionsElement) {
      this.realTimeData.activeConnections += Math.floor((Math.random() - 0.5) * 500);
      this.realTimeData.activeConnections = Math.max(1000, Math.min(10000, this.realTimeData.activeConnections));
      connectionsElement.textContent = this.realTimeData.activeConnections.toLocaleString();
    }

    if (bandwidthElement) {
      this.realTimeData.bandwidthUsage += Math.floor((Math.random() - 0.5) * 100);
      this.realTimeData.bandwidthUsage = Math.max(200, Math.min(2000, this.realTimeData.bandwidthUsage));
      bandwidthElement.textContent = this.realTimeData.bandwidthUsage + ' MB/s';
    }
  }

  // Form Handlers
  setupFormHandlers() {
    // Handle all button clicks
    document.addEventListener('click', (e) => {
      if (e.target.matches('.btn-primary, .btn-secondary, .btn-danger')) {
        this.handleButtonClick(e);
      }
    });

    // Handle compliance card interactions
    const complianceCards = document.querySelectorAll('.compliance-card');
    complianceCards.forEach(card => {
      card.addEventListener('click', () => {
        this.showComplianceDetails(card);
      });
    });
  }

  handleButtonClick(e) {
    const button = e.target;
    const buttonText = button.textContent.trim();

    // Don't handle buttons that already have specific handlers
    if (button.id === 'testRule' || button.id === 'saveRule') {
      return;
    }

    switch (buttonText) {
      case 'View All':
        this.navigateToSection('threats');
        break;
      case 'Create New Rule':
        this.showRuleBuilderModal();
        break;
      case 'New Policy':
        this.showNewPolicyModal();
        break;
      case 'Apply Template':
        this.applyPolicyTemplate(button);
        break;
      case 'Emergency Response':
        this.activateEmergencyResponse();
        break;
      case 'Create Incident':
        this.showCreateIncidentModal();
        break;
      case 'Export Logs':
        this.exportLogs();
        break;
      case 'Live View':
        this.toggleLiveView();
        break;
    }
  }

  showRuleBuilderModal() {
    this.showNotification('Rule builder expanded. Create your custom security rule.', 'info');
    
    // Focus on rule name input
    const ruleNameInput = document.getElementById('ruleName');
    if (ruleNameInput) {
      ruleNameInput.focus();
    }
  }

  showNewPolicyModal() {
    this.showNotification('Policy creation wizard would open here.', 'info');
  }

  applyPolicyTemplate(button) {
    const templateCard = button.closest('.template-card');
    const templateName = templateCard.querySelector('h4').textContent;
    
    button.textContent = 'Applying...';
    button.disabled = true;
    
    setTimeout(() => {
      button.textContent = 'Applied';
      button.style.backgroundColor = 'var(--success-color)';
      
      this.showNotification(`${templateName} template applied successfully.`, 'success');
      
      setTimeout(() => {
        button.textContent = 'Apply Template';
        button.disabled = false;
        button.style.backgroundColor = '';
      }, 3000);
    }, 2000);
  }

  activateEmergencyResponse() {
    const confirmation = confirm('Are you sure you want to activate emergency response mode? This will enable maximum security protocols.');
    
    if (confirmation) {
      this.showNotification('Emergency response mode activated. All security systems are now at maximum alert.', 'warning');
      
      // Update threat level indicator
      const threatBadge = document.querySelector('.threat-badge');
      if (threatBadge) {
        threatBadge.textContent = 'Threat Level: Critical';
        threatBadge.className = 'threat-badge critical';
        threatBadge.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
        threatBadge.style.color = 'var(--danger-color)';
        threatBadge.style.borderColor = 'rgba(239, 68, 68, 0.2)';
      }
    }
  }

  showCreateIncidentModal() {
    this.showNotification('Incident creation form would open here.', 'info');
  }

  exportLogs() {
    this.showNotification('Preparing log export... Download will start shortly.', 'info');
    
    // Simulate file download
    setTimeout(() => {
      const now = new Date();
      const filename = `secureshield-logs-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}.csv`;
      
      this.showNotification(`Logs exported successfully as ${filename}`, 'success');
    }, 2000);
  }

  toggleLiveView() {
    const button = event.target;
    const isActive = button.textContent === 'Stop Live View';
    
    if (isActive) {
      button.textContent = 'Live View';
      button.classList.remove('btn-danger');
      button.classList.add('btn-primary');
      this.showNotification('Live view disabled.', 'info');
    } else {
      button.textContent = 'Stop Live View';
      button.classList.remove('btn-primary');
      button.classList.add('btn-danger');
      this.showNotification('Live view enabled. Real-time monitoring active.', 'success');
    }
  }

  showComplianceDetails(card) {
    const framework = card.querySelector('h4').textContent;
    const score = card.querySelector('.compliance-score').textContent;
    const status = card.querySelector('.compliance-status').textContent;
    
    this.showNotification(`${framework}: ${score} compliance score - ${status}`, 'info');
  }

  // Responsive Design Handlers
  setupResponsiveDesign() {
    this.handleMobileNavigation();
    this.handleWindowResize();
  }

  handleMobileNavigation() {
    // Add mobile menu toggle if needed
    const header = document.querySelector('.header');
    
    if (window.innerWidth <= 768) {
      this.addMobileMenuToggle();
    }
    
    window.addEventListener('resize', () => {
      if (window.innerWidth <= 768) {
        this.addMobileMenuToggle();
      } else {
        this.removeMobileMenuToggle();
      }
    });
  }

  addMobileMenuToggle() {
    const header = document.querySelector('.header-left');
    
    if (!document.querySelector('.mobile-menu-toggle')) {
      const toggleButton = document.createElement('button');
      toggleButton.className = 'mobile-menu-toggle btn-secondary';
      toggleButton.innerHTML = '☰';
      toggleButton.style.marginRight = '1rem';
      
      toggleButton.addEventListener('click', this.toggleMobileSidebar.bind(this));
      
      header.insertBefore(toggleButton, header.firstChild);
    }
  }

  removeMobileMenuToggle() {
    const toggle = document.querySelector('.mobile-menu-toggle');
    if (toggle) {
      toggle.remove();
    }
  }

  toggleMobileSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('open');
  }

  handleWindowResize() {
    window.addEventListener('resize', () => {
      // Redraw charts on resize
      Object.values(this.charts).forEach(chart => {
        if (chart && typeof chart.resize === 'function') {
          chart.resize();
        }
      });
    });
  }

  // Notification System
  showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      existingNotification.remove();
    }

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
      <div class="notification-content">
        <span class="notification-message">${message}</span>
        <button class="notification-close">&times;</button>
      </div>
    `;

    // Style the notification
    Object.assign(notification.style, {
      position: 'fixed',
      top: '20px',
      right: '20px',
      zIndex: '10000',
      backgroundColor: type === 'success' ? 'var(--success-color)' : 
                      type === 'error' ? 'var(--danger-color)' : 
                      type === 'warning' ? 'var(--warning-color)' : 
                      'var(--info-color)',
      color: 'white',
      padding: '1rem',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-lg)',
      maxWidth: '400px',
      opacity: '0',
      transform: 'translateX(100%)',
      transition: 'all 0.3s ease'
    });

    document.body.appendChild(notification);

    // Animate in
    setTimeout(() => {
      notification.style.opacity = '1';
      notification.style.transform = 'translateX(0)';
    }, 10);

    // Handle close button
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
      this.hideNotification(notification);
    });

    // Auto-hide after 5 seconds
    setTimeout(() => {
      if (document.body.contains(notification)) {
        this.hideNotification(notification);
      }
    }, 5000);
  }

  hideNotification(notification) {
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(100%)';
    
    setTimeout(() => {
      if (document.body.contains(notification)) {
        notification.remove();
      }
    }, 300);
  }

  // Utility Methods
  formatNumber(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  formatBytes(bytes) {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 Bytes';
    
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  }

  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.secureShieldDashboard = new SecureShieldDashboard();
});

// Handle page visibility change to pause/resume real-time updates
document.addEventListener('visibilitychange', () => {
  if (window.secureShieldDashboard) {
    if (document.hidden) {
      // Page is hidden, could pause updates
      console.log('Dashboard paused');
    } else {
      // Page is visible, resume updates
      console.log('Dashboard resumed');
    }
  }
});

// Global error handler
window.addEventListener('error', (e) => {
  console.error('Dashboard error:', e.error);
  
  if (window.secureShieldDashboard) {
    window.secureShieldDashboard.showNotification(
      'An error occurred. Please refresh the page if issues persist.',
      'error'
    );
  }
});
