import os
from flask import Flask, render_template_string

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

@app.route('/')
def index():
    # Read the HTML file and serve it
    try:
        with open('index.html', 'r', encoding='utf-8') as f:
            html_content = f.read()
        return html_content
    except FileNotFoundError:
        return '''
        <!DOCTYPE html>
        <html>
        <head>
            <title>SecureShield WAF - File Not Found</title>
            <style>
                body { 
                    font-family: Arial, sans-serif; 
                    background: #0f172a; 
                    color: #f8fafc; 
                    padding: 2rem; 
                    text-align: center; 
                }
                .error { 
                    background: #1e293b; 
                    padding: 2rem; 
                    border-radius: 0.5rem; 
                    border: 1px solid #334155;
                    max-width: 600px;
                    margin: 2rem auto;
                }
            </style>
        </head>
        <body>
            <div class="error">
                <h1>🛡 SecureShield WAF</h1>
                <h2>Dashboard files not found</h2>
                <p>Please ensure index.html, style.css, and script.js are in the application directory.</p>
            </div>
        </body>
        </html>
        ''', 404

@app.route('/style.css')
def styles():
    try:
        with open('style.css', 'r', encoding='utf-8') as f:
            css_content = f.read()
        return css_content, 200, {'Content-Type': 'text/css'}
    except FileNotFoundError:
        return '/* CSS file not found */', 404, {'Content-Type': 'text/css'}

@app.route('/script.js')
def scripts():
    try:
        with open('script.js', 'r', encoding='utf-8') as f:
            js_content = f.read()
        return js_content, 200, {'Content-Type': 'application/javascript'}
    except FileNotFoundError:
        return '// JavaScript file not found', 404, {'Content-Type': 'application/javascript'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
