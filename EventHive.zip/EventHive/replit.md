# SecureShield WAF - Enterprise Security Platform

## Overview

SecureShield WAF is a web application firewall (WAF) dashboard built as a comprehensive security monitoring and management platform. The application provides enterprise-level security features including threat detection, traffic monitoring, rules engine, security policies management, and incident response capabilities. It's designed as a single-page application with a modern dark-themed interface featuring real-time monitoring capabilities and interactive security management tools.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a client-side rendered single-page application (SPA) architecture:
- **Static File Serving**: HTML, CSS, and JavaScript files served directly by Flask
- **Component-Based Design**: JavaScript class-based architecture with SecureShieldDashboard as the main controller
- **Responsive Layout**: CSS Grid and Flexbox-based layout with sidebar navigation and main content area
- **Real-time Updates**: JavaScript-based polling for live security metrics and monitoring data
- **Interactive Charts**: Chart.js integration for data visualization and security analytics

### Backend Architecture
Simple Flask-based web server with minimal complexity:
- **Static Content Server**: Primary purpose is serving the frontend assets (HTML, CSS, JS)
- **Session Management**: Basic Flask session configuration with secret key support
- **Error Handling**: Custom 404 pages with branded styling
- **Environment Configuration**: Environment variable support for production deployment

### Frontend Components
- **Navigation System**: Multi-section dashboard with dynamic content switching
- **Security Modules**: Dashboard, Rules Engine, Threat Detection, Traffic Monitoring, Security Policies, and Incident Response
- **Data Visualization**: Real-time charts and graphs for security metrics
- **Rule Builder**: Interactive interface for creating and managing WAF rules
- **Threat Management**: Table-based threat detection and response interface

### Design Patterns
- **CSS Custom Properties**: Centralized theming system for consistent dark mode styling
- **Modular JavaScript**: Class-based organization with separate methods for different functionalities
- **Progressive Enhancement**: Base HTML structure enhanced with JavaScript interactivity
- **Mobile-First Design**: Responsive design patterns for cross-device compatibility

## External Dependencies

### Frontend Libraries
- **Chart.js**: Data visualization library loaded via CDN for security metrics and analytics charts
- **Modern Browser APIs**: Relies on native JavaScript features for DOM manipulation and event handling

### Runtime Environment
- **Flask Framework**: Python web framework for serving static content
- **Python Standard Library**: File I/O operations and environment variable handling

### Development Dependencies
- **Static Assets**: Self-contained CSS and JavaScript files with no build process required
- **Font System**: System font stack with fallbacks for cross-platform compatibility

### Deployment Requirements
- **Environment Variables**: SESSION_SECRET for production security
- **File System**: Requires read access to static HTML, CSS, and JavaScript files
- **Port Configuration**: Standard Flask development server or WSGI deployment